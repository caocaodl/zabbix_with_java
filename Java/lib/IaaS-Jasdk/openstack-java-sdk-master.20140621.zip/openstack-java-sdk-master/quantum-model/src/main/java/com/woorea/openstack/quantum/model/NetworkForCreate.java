package com.woorea.openstack.quantum.model;

import org.codehaus.jackson.map.annotate.JsonRootName;

@SuppressWarnings("serial")
@JsonRootName("network")
@Deprecated
public class NetworkForCreate extends Network {
}
