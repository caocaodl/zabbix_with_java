package com.woorea.openstack.nova.model;

import java.io.Serializable;

import org.codehaus.jackson.map.annotate.JsonRootName;

@JsonRootName("volume-type")
public class VolumeType implements Serializable {

}
