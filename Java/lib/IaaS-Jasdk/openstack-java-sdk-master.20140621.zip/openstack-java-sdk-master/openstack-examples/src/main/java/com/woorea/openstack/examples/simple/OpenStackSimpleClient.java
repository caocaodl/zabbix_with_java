package com.woorea.openstack.examples.simple;


public class OpenStackSimpleClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		OpenStackClient client = new OpenStackClient(ExamplesConfiguration.KEYSTONE_AUTH_URL);
//		Access access = client.request("/tokens").execute("POST", Entity.json("{\"auth\":{\"passwordCredentials\":{\"username\":\"\",\"password\":\"\"}}}"), Access.class);
//		System.out.println(access);
	}

}
