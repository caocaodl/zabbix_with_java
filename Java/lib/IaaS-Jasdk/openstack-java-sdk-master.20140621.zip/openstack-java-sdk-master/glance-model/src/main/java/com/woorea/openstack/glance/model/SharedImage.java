package com.woorea.openstack.glance.model;

public class SharedImage {
	
}