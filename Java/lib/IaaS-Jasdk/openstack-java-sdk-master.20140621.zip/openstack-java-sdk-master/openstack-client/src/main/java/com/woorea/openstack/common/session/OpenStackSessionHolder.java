package com.woorea.openstack.common.session;
//package org.openstack.common.session;
//
//public class OpenStackSessionHolder {
//
//	private static final ThreadLocal<OpenStackSession> HOLDER = new ThreadLocal<OpenStackSession>();
//	
//	public static OpenStackSession getSession() {
//		return HOLDER.get();
//	}
//	
//	public static void setSession(OpenStackSession session) {
//		HOLDER.set(session);
//	}
//
//}
