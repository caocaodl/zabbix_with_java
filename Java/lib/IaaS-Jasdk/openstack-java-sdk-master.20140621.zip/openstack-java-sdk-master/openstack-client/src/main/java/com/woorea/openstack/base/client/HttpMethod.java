package com.woorea.openstack.base.client;

public enum HttpMethod {
	HEAD, GET, POST, PUT, PATCH, DELETE, OPTIONS, TRACE
}
