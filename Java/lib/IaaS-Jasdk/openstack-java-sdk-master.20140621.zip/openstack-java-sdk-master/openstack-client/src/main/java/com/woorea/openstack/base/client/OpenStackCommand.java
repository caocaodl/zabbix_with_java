package com.woorea.openstack.base.client;
//package org.openstack.base.client;
//
//public interface OpenStackCommand<R> {
//
//	OpenStackRequest createRequest(OpenStackClient connector);
//
//}
